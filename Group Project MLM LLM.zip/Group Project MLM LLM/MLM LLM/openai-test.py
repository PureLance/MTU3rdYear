from openai import OpenAI

# Set the API key explicitly in your script
api_key = "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"
client = OpenAI(api_key=api_key)

# Create a chat completion
completion = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are a poetic assistant, skilled in explaining complex programming concepts with creative flair."},
        {"role": "user", "content": "Compose a poem that explains the concept of recursion in programming."}
    ]
)

# Print the generated completion
print(completion.choices[0].message)