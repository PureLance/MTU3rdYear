import pandas as pd
import openai
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from chatterbot import ChatBot
from googletrans import Translator

# Set your OpenAI GPT-3 API key
openai.api_key = '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'

# Load the dataset
df = pd.read_csv("dataset.csv")

# Train-test split
x_train, x_test, y_train, y_test = train_test_split(
    df.iloc[:, 1:], df['Disease'], test_size=0.2, random_state=42
)

# Use LabelEncoder to convert disease names to numerical labels
label_encoder = LabelEncoder()
y_train_encoded = label_encoder.fit_transform(y_train)

# Convert categorical features to numerical format using one-hot encoding
x_train_encoded = pd.get_dummies(x_train)

# Train the Random Forest model
forest = RandomForestClassifier(random_state=42)
forest.fit(x_train_encoded, y_train_encoded)

# Set up the chatbot
chatbot = ChatBot('HealthAI Bot')

# Google Translate API
translator = Translator()

# Initialize variables to store user symptoms and predicted disease
user_symptoms = {}
predicted_disease = None

# Define a function to generate health advice using GPT-3
def generate_health_advice(prompt):
    response = openai.Completion.create(
        model="text-davinci-002",
        prompt=prompt,
        temperature=0.7,
        max_tokens=150,
        n=1,
    )
    return response['choices'][0]['text'].strip()

# Define a function to translate text
def translate_text(text, target_language='en'):
    translation = translator.translate(text, dest=target_language)
    return translation.text

# Function to suggest symptoms based on user input
def suggest_symptoms(input_text):
    symptoms = x_train_encoded.columns
    input_text_lower = input_text.lower().replace(" ", "_")

    # Filter symptoms based on input
    suggestions = [symptom for symptom in symptoms if input_text_lower in symptom.lower()]

    return suggestions

while True:
    user_input = input("Enter a symptom name or part of it (type 'stop' to stop): ").lower()

    if user_input == 'stop':
        break

    suggestions = suggest_symptoms(user_input)

    if suggestions:
        print("\nSuggestions:")
        for i, suggestion in enumerate(suggestions, start=1):
            print(f"{i}. {suggestion}")

        while True:
            choice = input("Please enter the symptoms number or enter the full symptom name: ")

            if choice.isdigit() and 1 <= int(choice) <= len(suggestions):
                user_symptoms[suggestions[int(choice) - 1]] = 1
                break
            elif choice in suggestions:
                user_symptoms[choice] = 1
                break
            else:
                print("Invalid choice. Please choose a valid number or enter the full symptom name.")
    else:
        print("No suggestions found. Please try a different input.")

    user_input_columns = x_train_encoded.columns
    user_input_data = {col: user_symptoms.get(col, 0) for col in user_input_columns}
    user_input_df = pd.DataFrame([user_input_data], columns=user_input_columns)

    num_values_entered = sum(user_symptoms.values())
    if num_values_entered > 3:
        user_input_encoded = pd.get_dummies(user_input_df)
        user_input_encoded = user_input_encoded.reindex(columns=x_train_encoded.columns, fill_value=0)

        user_pred = forest.predict(user_input_encoded)
        predicted_disease = label_encoder.inverse_transform(user_pred)

        # Generate dynamic health advice using GPT-3
        prompt = f"User has symptoms: {', '.join(user_symptoms.keys())}. Predicted disease: {predicted_disease}. Generate health advice. Keep it as a rough summary. Don't list out the symptoms in your advice"
        dynamic_health_advice = generate_health_advice(prompt)

        print("\nAnalysis of input:")
        print(f"Based on the given symptoms, we predict you are at risk of having {predicted_disease[0]}.")

        for symptom, value in user_symptoms.items():
            display_name = symptom.replace('_', ' ')
            print(f" - {display_name}: {'Yes' if value == 1 else 'No'}")

        response = input("\nDo you want to enter more symptoms? (yes/no): ").lower()
        if response != 'yes':
            # Print advice after the user decides to stop entering symptoms
            if num_values_entered > 3:
                # Translate the dynamic health advice to the user's language
                target_language = input(
                    "Enter the target language code:\n"
                    "  'en' for English\n"
                    "  'es' for Spanish\n"
                    "  'fr' for French\n"
                    "  'de' for German\n"
                    "  'zh' for Chinese\n"
                    "  'ja' for Japanese\n"
                    "  'ru' for Russian\n"
                    "  'ar' for Arabic\n"
                    "  'pt' for Portuguese\n"
                    "  'hi' for Hindi\n"
                    "Your choice: ").lower()

                translated_advice = translate_text(dynamic_health_advice, target_language=target_language)
                print(f"\nDiseaseBot Advice:")
                print(translated_advice)

                # Chat with HealthAI Bot about the predicted disease
                while True:
                    user_question = input("\nAsk HealthAI Bot a question (type 'stop' to end): ")

                    if user_question.lower() == 'stop':
                        break

                    # Include the predicted disease in the prompt
                    if any(symptom_value == 1 for symptom_value in user_symptoms.values()):
                        prompt = f"""User's Question: {user_question}
Generate a response providing information or advice related to the user's health. If the user asks if you are
    chat-GPT, say you are HealthBotAI then ask them to only ask health-based questions, tell them you are also a chatbot, 
    with the usual disclaimer that you are not a health professional. The predicted disease is {predicted_disease[0]}."""
                    else:
                        prompt = f"""User's Question: {user_question}
Generate a response indicating that the user needs to provide information about their health symptoms before any health advice can be given."""

                    # Use the GPT-3 API to get a response with the customized prompt
                    gpt_response = generate_health_advice(prompt)
                    translated_gpt_response = translate_text(gpt_response, target_language=target_language)
                    print(f"\nHealthAI Bot:")
                    print(translated_gpt_response)

                # Move this break outside of the if block
                break
