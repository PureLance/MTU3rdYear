#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on a rainy day

@author: XYZ


Student Name: Lance Hierco

Student ID: R00202072

Cohort: SD3B

"""

import numpy as np
import pandas as pd

# Extract names from files
fileNames = [
    "1-cow-potato-Ireland.txt",
    "2-giraffe-tomato-Namibia.txt",
    "3-rabbit-banana-Iceland.txt",
    "4-sheep-tomato-Egypt.txt",
    "5-snake-cucumber-England.txt",
    "6-sparrow-carrot-Turkey.txt",
    "7-fish-mushroom-Norway.txt",
    "8-snail-onion-Russia.txt",
    "9-ant-celery-China.txt",
    "10-elephant-plum-France.txt",
    "11-cat-pomegranate-Iran.txt",
    "12-deer-banana-Colombia.txt",
    "13-parrot-apricot-Greece.txt",
]

data = []

# Get the animal, vegetable, and country names from the file
for file_name in fileNames:
    # Extract animal, vegetable, and country names from the file name
    base_name = file_name.split('.')[0]
    index_number, animal_name, veg_fruit_name, country_name = base_name.split('-')

    # Read the content of the file word by word
    with open(file_name, 'r') as file:
        content = file.read()
        words = content.split()

    # Clean words so it does not have non-alphabetic characters and remove hyphens
    cleaned_words = [word.strip('!').strip('-').lower() for word in words]

    # Count words in a case-insensitive manner/ make all words lowercase
    cleaned_words = np.array(cleaned_words)
    animal_count = np.sum(cleaned_words == animal_name.lower())
    veg_fruit_count = np.sum(cleaned_words == veg_fruit_name.lower())
    country_count = np.sum(cleaned_words == country_name.lower())

    data.append([index_number, veg_fruit_name, country_name, animal_count, veg_fruit_count, country_count])

df = pd.DataFrame(data, columns=["Animal Name", "Vegetable/Fruit Name", "Country Name", "Animal Count", "Veg/Fruit Count", "Country Count"])
print(df)

#b Count the empty lines

def countEmptyLines(content):
    lines=content.split('\n')
    emptyLineCount = sum(i for lines in lines if not line.strip())
    return emptyLineCount

#c Find largest word size

def findLargestWordSize(content):
    words=content.split()
    largestWordSize = max(len(word) for word in words)
    return largestWordSize

#d Find smallest sentence

def findSmallestSentenceSize(content):
    sentences = content.split('. ')
    smallestSentenceSize = min(len(sentence) for sentence in sentences if sentences.strip())
    return  smallestSentenceSize

#e Find the size of each file

def findFileSize(fileName):
    with open(fileName, 'r') as file:
        content = file.read()

        #split the spaces and characters
        fileSize = len("".join(content.split()))

    return fileSize

#Create numpy array with 5 columns and 13 rows
data = np.array(data)
print(data)

#Print following:

#a The rows that have the highest similarity between content and name

similarities = np.sum(data[:, 3:6])
maxSimilarity = np.max(similarities)
highestSimilarityRow = datap[similarities == maxSimilarity]

#b Find rows with more than 10 empty lines
emptyLineCount = np.array([countEmptyLines(content) for content in data[:, 3]])
rowWithMoreThan10Lines = data[emptyLineCount > 10]

#c Find largest word
largestWordSize = np.max(np.array(findLargestWordSize(content) for content in data[:, 3]))

#d Find size of smallest sentence
smallestSentenceSize = findSmallestSentenceSize(data)

#e Find the size of largest file
largestFileSize = np.max(np.array([findFileSize(file) for file in fileNames]))

#Print
print("Row with highest similarity:", highestSimilarityRow)
print("\nRow with more than 10 empty lines: ", rowWithMoreThan10Lines)
print("\nSize of largest word: ", largestWordSize)
print("\nSize of smallest sentence:", smallestSentenceSize)
print("\nSize of largest file:", largestFileSize)
