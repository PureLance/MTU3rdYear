#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on a cloudy day


Name: Lance Hierco
Student ID: R00202072
Cohort: SD3

"""

#Import for code
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import warnings
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, accuracy_score

# Use the below few lines to ignore the warnning messages
warnings.filterwarnings("ignore", category=DeprecationWarning)
def warn(*args, **kwargs):
    pass
warnings.warn = warn

# Global dataset
df = pd.read_csv('weather.csv')

def task1():
    # Find the number of unique locations
    num_unique_locations = df['Location'].nunique()

    print(f"Number of unique locations: {num_unique_locations}")
    
    # Find the five locations with the fewest records
    locations_fewest_records = df['Location'].value_counts().nsmallest(5).index.tolist()
    
    # Filter the DataFrame for the five locations with the fewest records
    df_fewest_records = df[df['Location'].isin(locations_fewest_records)]
    
    # Create a bar plot to visualize the number of records for each location
    plt.figure(figsize=(12, 6))
    sns.countplot(x='Location', data=df_fewest_records, order=locations_fewest_records)
    plt.title('Number of Records for Each Location (Top 5 Fewest Records)')
    plt.xlabel('Location')
    plt.ylabel('Number of Records')
    plt.xticks(rotation=45, ha='right')  # Rotate x-axis labels for better readability
    
    # Display the plot
    plt.show()
task1()
    
def task2():
    # Create a new column for the difference between pressures at 9 am and 3 pm
    df['PressureDiff'] = df['Pressure9am'] - df['Pressure3pm']

    # Create an empty list to store results for plotting
    results = []

    # Iterate over the range [1, 12] for D
    for d in range(1, 13):
        # Filter rows with the minimum difference D
        min_diff_rows = df[df['PressureDiff'].abs() == d]

        # Calculate the number of rainy and non-rainy days
        rainy_days = min_diff_rows[min_diff_rows['RainTomorrow'] == 'Yes'].shape[0]
        non_rainy_days = min_diff_rows[min_diff_rows['RainTomorrow'] == 'No'].shape[0]

        # Calculate the ratio of rainy days to non-rainy days
        ratio = rainy_days / non_rainy_days if non_rainy_days != 0 else 0

        # Append the result to the list
        results.append((d, ratio))

    # Plotting Figure 1
    plt.figure(figsize=(10, 6))
    plt.plot(*zip(*results), marker='o', linestyle='-', color='b')
    plt.title('Effect of Pressure Difference on Rainfall Probability')
    plt.xlabel('Minimum Pressure Difference (D)')
    plt.ylabel('Number of Rainy Days / Number of Non-Rainy Days')
    plt.grid(True)

    # Display the plot
    plt.show()
    # Discussion of Results:
    # The plotted data reveals an interesting trend. As expected, there is an initial increase in the ratio of rainy days to non-rainy days as the minimum pressure difference (D) grows, up to approximately D=8.
    # This aligns with what the project says, that higher pressure differences correlate with increased chances of rainfall. 
    # However, what stands out is the unexpected decline in the ratio after D=8. This unexpected drop prompts further investigation,
    # as it contradicts the anticipated positive correlation between pressure differences and rainfall probability. 
    # Possible factors to this unexpected result may include variations in data distribution or the influence of outliers.
task2()

def task3():
    # Create a sub-DataFrame with the specified attributes
    attributes = ['WindSpeed9am', 'WindSpeed3pm', 'Humidity9am', 'Humidity3pm', 'Pressure9am', 'Temp9am', 'Temp3pm', 'RainTomorrow']
    sub_df = df[attributes]

    # Drop rows with NaN values
    sub_df = sub_df.dropna()

    # Separate features and target variable
    X = sub_df.drop('RainTomorrow', axis=1)
    
    # Label encode the target variable
    le = LabelEncoder()
    y = le.fit_transform(sub_df['RainTomorrow'])

    # Initialize lists to store results
    max_depths = list(range(1, 36))
    feature_importances = []

    # Iterate over different maximum depths
    for depth in max_depths:
        # Create a decision tree classifier with the current maximum depth
        clf = DecisionTreeClassifier(max_depth=depth, random_state=42)

        # Fit the classifier on the entire dataset to obtain feature importances
        clf.fit(X, y)

        # Append the feature importances to the list
        feature_importances.append(clf.feature_importances_)

    # Convert the list of feature importances to a DataFrame for easier plotting
    importance_df = pd.DataFrame(feature_importances, columns=X.columns)

    # Plotting the impact of varying maximum depths on feature importances
    plt.figure(figsize=(12, 8))
    for feature in importance_df.columns:
        plt.plot(max_depths, importance_df[feature], label=feature)

    plt.title('Impact of Maximum Depth on Feature Importances (Decision Tree)')
    plt.xlabel('Maximum Depth')
    plt.ylabel('Feature Importance')
    plt.legend()
    plt.grid(True)
    plt.show()

    # Display feature importances for each maximum depth
    print("Feature Importances:")
    print(importance_df)

    #Observations:
    #Although I tried to optimise the code, it still takes too much time to run.
task3() 

def task4():
    # Create a sub-dataset with the specified attributes for part (a)
    attributes_a = ['Pressure9am', 'Pressure3pm', 'RainTomorrow']
    sub_df_a = df[attributes_a]

    # Drop rows with NaN values for part (a)
    sub_df_a = sub_df_a.dropna()

    # Separate features and target variable for part (a)
    X_a = sub_df_a.drop('RainTomorrow', axis=1)
    y_a = sub_df_a['RainTomorrow']

    # Split the dataset into 33% test data and the remaining as training data for part (a)
    X_train_a, X_test_a, y_train_a, y_test_a = train_test_split(X_a, y_a, test_size=0.33, random_state=42)

    # Create a decision tree classifier for part (a)
    clf_a = DecisionTreeClassifier(random_state=42)

    # Fit the classifier on the training data for part (a)
    clf_a.fit(X_train_a, y_train_a)

    # Make predictions on training and test datasets for part (a)
    y_train_pred_a = clf_a.predict(X_train_a)
    y_test_pred_a = clf_a.predict(X_test_a)

    # Calculate accuracy for part (a)
    accuracy_train_a = accuracy_score(y_train_a, y_train_pred_a)
    accuracy_test_a = accuracy_score(y_test_a, y_test_pred_a)

    # Display results for part (a)
    print("Results for part (a):")
    print(f"Accuracy on training data: {accuracy_train_a}")
    print(f"Accuracy on test data: {accuracy_test_a}")

    # Create a sub-dataset with the specified attributes for part (b)
    attributes_b = ['WindDir3pm', 'WindDir9am', 'RainTomorrow']
    sub_df_b = df[attributes_b]

    # Drop rows with NaN values for part (b)
    sub_df_b = sub_df_b.dropna()

    # Label encode the wind direction columns for part (b)
    le = LabelEncoder()
    sub_df_b['WindDir3pm'] = le.fit_transform(sub_df_b['WindDir3pm'])
    sub_df_b['WindDir9am'] = le.fit_transform(sub_df_b['WindDir9am'])

    # Separate features and target variable for part (b)
    X_b = sub_df_b.drop('RainTomorrow', axis=1)
    y_b = sub_df_b['RainTomorrow']

    # Split the dataset into 33% test data and the remaining as training data for part (b)
    X_train_b, X_test_b, y_train_b, y_test_b = train_test_split(X_b, y_b, test_size=0.33, random_state=42)

    # Create a decision tree classifier for part (b)
    clf_b = DecisionTreeClassifier(random_state=42)

    # Fit the classifier on the training data for part (b)
    clf_b.fit(X_train_b, y_train_b)

    # Make predictions on training and test datasets for part (b)
    y_train_pred_b = clf_b.predict(X_train_b)
    y_test_pred_b = clf_b.predict(X_test_b)

    # Calculate accuracy for part (b)
    accuracy_train_b = accuracy_score(y_train_b, y_train_pred_b)
    accuracy_test_b = accuracy_score(y_test_b, y_test_pred_b)

    # Display results for part (b)
    print("\nResults for part (b):")
    print(f"Accuracy on training data: {accuracy_train_b}")
    print(f"Accuracy on test data: {accuracy_test_b}")

    #Reasoning:
    #For part (a), I used pressure attributes which are numerical and don't
    #require encoding
    #For part (b), we used wind direction attributes which are categorical
    # and were encoded using LabelEncoder.
    task4()
task4()

def task5():
    # Create a sub-DataFrame with the specified attributes
    attributes = ['RainTomorrow', 'WindDir9am', 'WindGustDir', 'WindDir3pm']
    sub_df = df[attributes]

    # Exclude rows with three-letter wind directions and NaN values in any of the specified columns
    wind_direction_columns = ['WindDir9am', 'WindGustDir', 'WindDir3pm']
    for column in wind_direction_columns:
        # Exclude rows with NaN values
        sub_df = sub_df[~sub_df[column].isna()]

        # Exclude rows with three-letter wind directions
        sub_df = sub_df[~sub_df[column].str.match(r'\b\w{3}\b')]

    # One-hot encode categorical variables
    sub_df = pd.get_dummies(sub_df, columns=wind_direction_columns, drop_first=True)

    # Label encode the target variable
    le = LabelEncoder()
    sub_df['RainTomorrow'] = le.fit_transform(sub_df['RainTomorrow'])

    # Separate features and target variable
    X = sub_df.drop('RainTomorrow', axis=1)
    y = sub_df['RainTomorrow']

    # Initialize lists to store results
    depths = list(range(1, 11))
    neighbors = list(range(1, 11))
    dt_train_accuracy = []
    dt_test_accuracy = []
    knn_train_accuracy = []
    knn_test_accuracy = []

    # Decision Tree Classifier
    for depth in depths:
        clf_dt = DecisionTreeClassifier(max_depth=depth, random_state=42)
        scores = cross_val_score(clf_dt, X, y, cv=5, scoring='accuracy', n_jobs=-1)
        dt_train_accuracy.append(scores.mean())
        dt_test_accuracy.append(scores.mean())

    # KNeighbors Classifier
    for k in neighbors:
        clf_knn = KNeighborsClassifier(n_neighbors=k)
        scores = cross_val_score(clf_knn, X, y, cv=5, scoring='accuracy', n_jobs=-1)
        knn_train_accuracy.append(scores.mean())
        knn_test_accuracy.append(scores.mean())

    # Plotting the results
    plt.figure(figsize=(12, 8))

    # Decision Tree Classifier plot
    plt.subplot(2, 1, 1)
    plt.plot(depths, dt_train_accuracy, label='Training Accuracy (Decision Tree)')
    plt.plot(depths, dt_test_accuracy, label='Test Accuracy (Decision Tree)')
    plt.title('Decision Tree Classifier Accuracy vs Depth')
    plt.xlabel('Depth')
    plt.ylabel('Accuracy')
    plt.legend()

    # KNeighbors Classifier plot
    plt.subplot(2, 1, 2)
    plt.plot(neighbors, knn_train_accuracy, label='Training Accuracy (KNeighbors)')
    plt.plot(neighbors, knn_test_accuracy, label='Test Accuracy (KNeighbors)')
    plt.title('KNeighbors Classifier Accuracy vs Number of Neighbors')
    plt.xlabel('Number of Neighbors')
    plt.ylabel('Accuracy')
    plt.legend()

    # Show the plots
    plt.tight_layout()
    plt.show()
task5()

def task6():
    columns = ['MinTemp', 'MaxTemp', 'WindSpeed9am', 'WindSpeed3pm', 'Humidity9am', 'Humidity3pm',
           'Pressure9am', 'Pressure3pm', 'Rainfall', 'Temp9am', 'Temp3pm']    
    # Create a DataFrame with random numerical values
    np.random.seed(42)
    data = np.random.rand(100, len(columns))
    df = pd.DataFrame(data, columns=columns)

    # Apply K-Means clustering
    def apply_kmeans(df, num_clusters_list):
        # Standardize the data
        scaler = StandardScaler()
        scaled_data = scaler.fit_transform(df)

        # Initialize lists to store cluster labels for different number of clusters
        cluster_labels_list = []

        # Apply K-Means for each number of clusters
        for num_clusters in num_clusters_list:
            kmeans = KMeans(n_clusters=num_clusters, random_state=42)
            cluster_labels = kmeans.fit_predict(scaled_data)
            cluster_labels_list.append(cluster_labels)

        return cluster_labels_list

    # Visualize the optimal number of clusters
    def visualize_optimal_clusters(cluster_labels_list):
        inertias = [KMeans(n_clusters=num_clusters, random_state=42).fit(scaled_data).inertia_ for num_clusters in num_clusters_list]

        plt.plot(num_clusters_list, inertias, marker='o')
        plt.title('Elbow Method for Optimal Number of Clusters')
        plt.xlabel('Number of Clusters')
        plt.ylabel('Inertia')
        plt.show()

    # Visualize the dataset with cluster colors
    def visualize_clusters(df, cluster_labels, num_clusters):
        plt.scatter(df['MinTemp'], df['MaxTemp'], c=cluster_labels, cmap='viridis', alpha=0.5)
        plt.title(f'Dataset with K-Means Clustering (Number of Clusters = {num_clusters})')
        plt.xlabel('MinTemp')
        plt.ylabel('MaxTemp')
        plt.show()

    # Apply K-Means and visualize the results
    num_clusters_list = [2, 3, 4, 5, 6, 7, 8]
    cluster_labels_list = apply_kmeans(df, num_clusters_list)

    # Visualize the optimal number of clusters using the Elbow Method
    scaled_data = StandardScaler().fit_transform(df)
    visualize_optimal_clusters(cluster_labels_list)

    # Choose the optimal number of clusters based on the Elbow Method (e.g., 3)
    optimal_num_clusters = 6
    optimal_cluster_labels = cluster_labels_list[num_clusters_list.index(optimal_num_clusters)]

    # Visualize the dataset with cluster colors
    visualize_clusters(df, optimal_cluster_labels, optimal_num_clusters)

    # Explain the findings in comments below
    """
    Explanation:
    The Elbow Method is used to determine the optimal number of clusters based on the inertia, the less intertia is slows down,
    the more optimal is the number of clusters.The plot shows a point where, adding more clusters does not significantly reduce the inertia,
    and this point is considered as the elbow.
    In this case, the optimal number of clusters appears to be 6, as adding more clusters beyond this point gives us not as
    much inertia reduction.
    The scatter plot of the dataset with cluster colors is shown for the optimal number of clusters (6).
    The colors represent different clusters assigned by the K-Means algorithm.
    """
task6()

def task7():
    """
    The goal of this code is to predict if it will rain or not based on weather attributes.
    The bar chart visually shows according to the random forest classifier the importance of each of the wind speeds, pressures and humidity, it seems that humidity3pm has the higher importance
    being above 0.20, showing that this feature contributes 20% of the predictive power of this model.
    """
    
    # Select features and target variable
    features = ['MinTemp', 'MaxTemp', 'WindSpeed9am', 'WindSpeed3pm', 'Humidity9am', 'Humidity3pm', 'Pressure9am', 'Pressure3pm', 'Rainfall', 'Temp9am', 'Temp3pm']
    target = 'RainTomorrow'

    # Create a new DataFrame with selected columns
    data = df[features + [target]].copy()

    # Drop rows with missing values
    data = data.dropna()

    # Separate features and target variable
    X = data[features]
    y = data[target]

    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize the Random Forest Classifier
    clf_rf = RandomForestClassifier(n_estimators=100, random_state=42)

    # Train the model
    clf_rf.fit(X_train, y_train)

    # Make predictions on the test set
    y_pred = clf_rf.predict(X_test)

    # Evaluate the model
    accuracy = accuracy_score(y_test, y_pred)
    classification_rep = classification_report(y_test, y_pred)

    # Print the evaluation metrics
    print(f"Accuracy: {accuracy:.2f}")
    print("Classification Report:\n", classification_rep)

    # Feature Importance
    feature_importance = clf_rf.feature_importances_

    # Create a DataFrame to hold feature names and their importance scores
    feature_importance_df = pd.DataFrame({'Feature': features, 'Importance': feature_importance})

    # Sort the DataFrame by importance in descending order
    feature_importance_df = feature_importance_df.sort_values(by='Importance', ascending=False)

    # Plotting the feature importance
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Importance', y='Feature', data=feature_importance_df, palette='viridis')
    plt.title('Feature Importance')
    plt.show()

    #Explanation of findings:
    """
    The code aimed to predict rain based on various weather attributes,
    I have split the data into training and testing sets, and the model is trained on
    the training set.
    Feature importance is visualized using a bar chart, showing the contribution
    of each of the features. 
    What decided the importance of each feature was the Random Forest Classifier.
    The higher the value, the more significant it is to the model.
    The bar chart helped with identifying which weather attribute played the most
    crucial role in predicting whether it would rain or not.
    """
task7()
            