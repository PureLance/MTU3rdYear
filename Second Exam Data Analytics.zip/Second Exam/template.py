#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on a sunny day


Student Name: Lance Hierco

Student ID: R00202072

Cohort: SD3-B

"""
import pandas as pd
import matplotlib.pyplot as plt
from collections import Counter
import re

#Read Movies-1.csv
movies_df = pd.read_csv("Movies-1.csv")

#Read main_genre.csv
main_genre_df = pd.read_csv("main_genre.csv", encoding='latin1')


def task1():
    #Count number of unique Main_Genres
    total_genres = movies_df['main_Genre'].nunique()

    #Find the most popular Main_Genre
    most_popular_genre = movies_df['main_Genre'].value_counts().idxmax()

    #Find the least popular Main_Genre
    least_popular_genre = movies_df['main_Genre'].value_counts().idxmin()


    #Display total number of genres
    print(f"Total number of unique main genres: {total_genres}")
    #Display most popular genre
    print(f"Most popular genre: {most_popular_genre}")
    #Display least popular genre
    print(f"Least popular genre: {least_popular_genre}")

    #Display the top 8 popular genres using bar plot
    genre_counts = movies_df['main_Genre'].value_counts().head(8)
    genre_counts.plot(kind="bar", title="Top 8 Popular Genres")
    plt.xlabel("Main Genre")
    plt.ylabel("Number of Movies")
    plt.show()
task1()

def task2():
    # Splitting and exploding most common genre
    most_common_genre = movies_df["Genre"].str.split(",").explode().value_counts().idxmax()

    # Splitting and exploding least common genre
    least_common_genre = movies_df["Genre"].str.split(",").explode().value_counts().idxmin()

    # Display most and least common genres
    print(f"Most common genre: {most_common_genre}")
    print(f"Least common genre: {least_common_genre}")
task2()

def task3():
    #Using global variable
    global movies_df 
    #Drop row if missing values
    movies_df = movies_df.dropna(subset=['Runtime'])

    #Extract numeric values from Runtime
    movies_df['Runtime'] = movies_df['Runtime'].str.extract('(\d+)').astype(float)


    #Calculate the interquartile range for movie duration
    Q1 = movies_df['Runtime'].quantile(0.25)
    Q3 = movies_df['Runtime'].quantile(0.75)
    IQR = Q3 - Q1


    #Lower and upperbound
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    #Find outliers
    outliers = movies_df[(movies_df['Runtime'] < lower_bound) | (movies_df['Runtime']>upper_bound)]
    
    #Display title of movies that are outliers
    print("Movies with outlier durations: ")
    print(outliers['Title'])

    #Visualize with boxplot
    plt.boxplot(movies_df['Runtime'])
    plt.title('Box Plot of Movie Duration (Runtime)')
    plt.ylabel("Runtime")
    plt.show()
task3()
       
def task4():

    #Check for null values in Number of Votes and Rating
    null_votes = movies_df['Number of Votes'].isnull().sum()
    null_rating = movies_df['Rating'].isnull().sum()

    #Fill null values with the average of existing values
    movies_df['Number of Votes'].fillna(movies_df['Number of Votes'].mean(), inplace=True)
    movies_df['Rating'].fillna(movies_df['Rating'].mean(), inplace = True)

    #Report if there are any null values
    print(f"Number of null values in Number of Votes: {null_votes}")
    print(f"Number of null values in Rating: {null_rating}")
    print("Null values are filled with average of existing values for each attribute")

    #Visualization
    plt.scatter(movies_df['Number of Votes'], movies_df['Rating'])
    plt.title("Relationship between Number of Votes and Rating")
    plt.xlabel("Number of Votes")
    plt.ylabel("Rating")
    plt.show()
task4()
 
def task5():
     #Define a function to clean the synopsis
    def clean_syno(synopsis):
        synopsis = synopsis.lower()  # Convert to lowercase
        synopsis = re.sub(r'[.,\'"\-]', '', synopsis)  # Remove all non alphabetic
        return synopsis.split() # Splits cleaned synopsis into individual lists of terms

    #Loop through each main genre in main_genre.csv
    for main_genre in main_genre_df.columns:
        # Step 4: Extract associated terms for the current main genre
        terms = main_genre_df[main_genre].dropna().tolist()

        #Create a list to store movie titles related to the current main genre
        related_movies = []

        #Loop through each movie in Movie-1.csv
        for index, movie in movies_df.iterrows(): #iterates through each row
            synopsis_terms = clean_syno(movie['Synopsis'])  #Clean the terms with function
            #Check if any term associated with the current main genre is present in the movie synopsis
            if any(term in synopsis_terms for term in terms):
                related_movies.append(movie['main_Genre']) #Append to movie

        #Determine the most frequent main genre related to the current main genre
        counter = Counter(related_movies) 

        #Check if the counter list is not empty before trying to access its elements
        if counter:
            most_frequent_main_genre = counter.most_common(1)[0][0]
            print(f"{main_genre}: {most_frequent_main_genre}")
        else:
            print(f"{main_genre}: No related movies found.")
task5()
   
def task6():
 
    
    # Group by 'main_Genre' and calculate average rating for each genre
    genre_avg_ratings = movies_df.groupby('main_Genre')['Rating'].mean().sort_values(ascending=False)

    # Plot a bar chart to visualize average ratings for each genre
    plt.figure(figsize=(10, 6))
    genre_avg_ratings.plot(kind='bar', color='skyblue')
    plt.title('Average Ratings Across Different Genres')
    plt.xlabel('Main Genre')
    plt.ylabel('Average Rating')
    plt.xticks(rotation=30, ha='right') # Rotating for better readablity
    plt.show()

        #Analyzing Movie Ratings Across Different Genres:
        #This visualization displays the average ratings for each main genre.
        #Filmmakers and studios can gain insights into audience preferences across genres.
task6()

